package com.hbd.divehub;

import android.app.Activity;
import android.os.Bundle;

public class AmphoraWall extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.amphorawall);
	}
	

}
